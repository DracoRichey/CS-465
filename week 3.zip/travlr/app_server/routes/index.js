const tripsController = require('../controllers/trips');
const express = require('express');
const router = express.Router();
const ctrlMain = require('../controllers/main');

// Home page
router.get('/', ctrlMain.index);
router.get('/trips', tripsController.tripList);

module.exports = router;

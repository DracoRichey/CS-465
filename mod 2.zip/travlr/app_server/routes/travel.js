const express = require('express');
const router = express.Router();
const ctrlTravel = require('../controllers/travel');

// Trips page
router.get('/', ctrlTravel.list);

module.exports = router;

// Trips page controller
module.exports.list = (req, res) => {
  const trips = [
    { code: 'tky-3', name: 'Tokyo Weekend', location: 'Tokyo, Japan', nights: 3, price: 599 },
    { code: 'alps-5', name: 'Swiss Alps Hike', location: 'Zermatt, Switzerland', nights: 5, price: 1299 },
    { code: 'syd-7', name: 'Sydney & Coast', location: 'Sydney, Australia', nights: 7, price: 1499 }
  ];

  res.render('travel', {
    title: 'Travlr | Trips',
    trips,
    count: trips.length
  });
};

// app.js
const express = require('express');
const path = require('path');
const morgan = require('morgan');
const { engine } = require('express-handlebars');

const app = express();

// 1) Handlebars setup
app.engine('.hbs', engine({
  extname: '.hbs',
  defaultLayout: 'main',
  layoutsDir: path.join(__dirname, 'app_server', 'views', 'layouts'),
  partialsDir: path.join(__dirname, 'app_server', 'views', 'partials'),
}));
app.set('view engine', '.hbs');
app.set('views', path.join(__dirname, 'app_server', 'views'));

// 2) Middleware
app.use(morgan('dev'));
app.use(express.static(path.join(__dirname, 'public')));

// Make year available everywhere
app.use((req, res, next) => {
  res.locals.year = new Date().getFullYear();
  next();
});

// 3) Routes
const indexRouter = require('./app_server/routes/index');
const travelRouter = require('./app_server/routes/travel');
app.use('/', indexRouter);
app.use('/travel', travelRouter);

// 4) Start server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Travlr running at http://localhost:${PORT}`);
});
